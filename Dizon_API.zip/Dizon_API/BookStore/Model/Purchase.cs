﻿namespace BookStore.Model
{
    public class Purchase
    {
        public int PurchaseId { get; set; }
        public int BookId { get; set; }
        public int UserId { get; set; }
        public Book Book { get; set; }  // Navigation property to Book


        public int CustomerId { get; set; }
        public DateTime PurchaseDate { get; set; }
        public decimal PriceAmount { get; set; }
        public string Stock { get; set; }
    }
}
