﻿namespace BookStore.Model
{
    public class Report
    {
        public class BookCirculationReport
        {
            public int BookId { get; set; }
            public string Title { get; set; }
            public string Author { get; set; }
            public int TotalPurchase { get; set; }
        }

        public class OverdueReport
        {
            public int LoanId { get; set; }
            public string BookTitle { get; set; }
            public string CustomerName { get; set; }
            public DateTime DueDate { get; set; }
            public decimal PriceAmount { get; set; }
        }

        public class CustomerActivityReport
        {
            public string CustomerName { get; set; }
            public int TotalPurchases { get; set; }
            public int OverduePurchases { get; set; }
        }
    }
}

