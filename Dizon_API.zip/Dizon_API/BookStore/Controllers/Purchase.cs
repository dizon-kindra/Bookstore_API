﻿using BookStore.Data;
using BookStore.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BookStore.Controllers
{
    public class Purchase
    {
        [ApiController]
        [Route("api/[controller]")]
        [Authorize] // Require authentication for all endpoints
        public class PurchaseController : ControllerBase
        {
            // Get all purchases
            [HttpGet("GetAllPurchases")]
            public ActionResult<IEnumerable<Purchase>> GetAllPurchases()
            {
                return Ok(MemoryStorage.Purchases);
            }

            // Add a new purchase
            [HttpPost("AddPurchase")]
            public ActionResult AddPurchase([FromBody] Purchase purchase)
            {
                if (purchase == null || purchase.BookId <= 0 || purchase.CustomerId <= 0 || purchase.PurchaseDate == null)
                {
                    return BadRequest("Invalid purchase data.");
                }

                purchase.PurchaseId = MemoryStorage.Purchases.Count + 1;
                MemoryStorage.Purchases.Add(purchase);
                return Ok("Purchase added successfully.");
            }

            // Update an existing purchase
            [HttpPut("UpdatePurchase/{id}")]
            public ActionResult UpdatePurchase(int id, [FromBody] Purchase updatedPurchase)
            {
                var purchase = MemoryStorage.Purchases.FirstOrDefault(p => p.PurchaseId == id);
                if (purchase == null) return NotFound("Purchase not found.");

                purchase.BookId = updatedPurchase.BookId;
                purchase.UserId = updatedPurchase.UserId;
                purchase.CustomerId = updatedPurchase.CustomerId;
                purchase.PurchaseDate = updatedPurchase.PurchaseDate;
                purchase.PriceAmount = updatedPurchase.PurchaseDate;
                purchase.Stock = updatedPurchase.Stock;
                return Ok("Purchase updated successfully.");
            }

            // Delete a purchase
            [HttpDelete("DeletePurchase/{id}")]
            public ActionResult DeletePurchase(int id)
            {
                var purchase = MemoryStorage.Purchases.FirstOrDefault(p => p.PurchaseId == id);
                if (purchase == null) return NotFound("Purchase not found.");

                MemoryStorage.Purchases.Remove(purchase);
                return Ok("Purchase deleted successfully.");
            }

            // Get purchase by ID
            [HttpGet("GetPurchase/{id}")]
            public ActionResult<Purchase> GetPurchase(int id)
            {
                var purchase = MemoryStorage.Purchases.FirstOrDefault(p => p.PurchaseId == id);
                if (purchase == null) return NotFound("Purchase not found.");

                return Ok(purchase);
            }
        }

    }
}
