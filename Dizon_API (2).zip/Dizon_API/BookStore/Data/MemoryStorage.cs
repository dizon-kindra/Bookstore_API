﻿using BookStore.Controllers;
using BookStore.Data;
using BookStore.Model;
using static System.Reflection.Metadata.BlobBuilder;
using static BookStore.Model.Report;

namespace BookStore.Data
{
    public static class MemoryStorage
    {
        public static string salt = ")GN#447#^nryrETNwrbR%#&NBRE%#%BBDT#%";

        public static List<Book> Books = new List<Book>();
        public static List<Customer> Customers = new List<Customer>
        {
        new Customer
        {
            CustomerId = 1,
            Username = "admin",
            FirstName = "John",
            LastName = "Doe",
            Email = "john.doe@example.com",
            Password = "dde6a80ee27ed148c86020e2cfaf6d28", // Presuming this is the hashed password
            PhoneNumber = "+1234567890",
            Address = "123 Elm Street, Springfield, IL",
            Role = "Customer",
            Purchases = new List<Purchase> { new Purchase{ PurchaseId = 1, BookId = 1, PurchaseDate = DateTime.Now.AddDays(-10),} }
        },
        new Customer
        {
            CustomerId = 2,
            Username = "Jane",
            FirstName = "Jane",
            LastName = "Smith",
            Email = "jane.smith@example.com",
            Password = "6cb75f652a9b52798eb6cf2201057c73", // Presuming this is the hashed password
            PhoneNumber = "+1987654321",
            Address = "456 Oak Avenue, Springfield, IL",
            Role = "Customer",
            Purchases = new List<Purchase> { new Purchase { PurchaseId = 2, BookId = 2, PurchaseDate = DateTime.Now.AddDays(-5),} }
        },
        new Customer
        {
           CustomerId = 3,
            Username = "Mike",
            FirstName = "Mike",
            LastName = "Johnson",
            Email = "mike.johnson@example.com",
            Password = "819b0643d6b89dc9b579fdfc9094f28e", // Presuming this is the hashed password
            PhoneNumber = "+1239876543",
            Address = "789 Pine Road, Springfield, IL",
            Role = "Patron",
            Purchases = new List<Purchase> { new Purchase { PurchaseId = 3, BookId = 3, PurchaseDate = DateTime.Now.AddDays(-3),  } }
        }
        };
        public static List<Admin> Admins = new List<Admin>
        {
             // Seed
            new Admin
        {
            AdminId = 1,
            Username = "admin1",
            FirstName = "John",
            LastName = "Doe",
            Email = "john.doe@example.com",
            Password = "dde6a80ee27ed148c86020e2cfaf6d28" // Presuming this is the hashed password
        },
        new Admin
        {
             AdminId = 2,
            Username = "Janee",
            FirstName = "Jane",
            LastName = "Smith",
            Email = "jane.smith@example.com",
            Password = "6cb75f652a9b52798eb6cf2201057c73" // Presuming this is the hashed password
        },
        new  Admin
        {
            AdminId = 3,
            Username = "Mikee",
            FirstName = "Mike",
            LastName = "Johnson",
            Email = "mike.johnson@example.com",
            Password = "819b0643d6b89dc9b579fdfc9094f28e" // Presuming this is the hashed password
        },
        new Admin
        {
            AdminId = 4,
            Username = "Lisaa",
            FirstName = "Lisa",
            LastName = "Brown",
            Email = "lisa.brown@example.com",
            Password = "34cc93ece0ba9e3f6f235d4af979b16c" // Presuming this is the hashed password
        },
        new Admin
        {
            AdminId = 5,
            Username = "Samm",
            FirstName = "Samuel",
            LastName = "Green",
            Email = "samuel.green@example.com",
            Password = "db0edd04aaac4506f7edab03ac855d56" // Presuming this is the hashed password
        }
        };
        public static List<Purchase> Purchases = new List<Purchase>();
        public static List<BookCirculationReport> BookCirculationReports = new List<BookCirculationReport>();
        public static List<OverdueReport> OverdueReports = new List<OverdueReport>();
        public static List<CustomerActivityReport> CustomerActivityReports = new List<CustomerActivityReport>();

        static MemoryStorage()
        {
            // Seed Books
            Books.Add(new Book
            {
                BookId = 1,
                Title = "The Great Gatsby",
                Author = "F. Scott Fitzgerald",
                ISBN = "9780743273565",
                Genre = "Fiction",
                Price = 12.99m, // Add Price
                Stock = 8, // Use Stock instead of TotalCopies and AvailableCopies
                CreatedAt = DateTime.Now,
                UpdatedAt = DateTime.Now
            });
            Books.Add(new Book
            {
                BookId = 2,
                Title = "1984",
                Author = "George Orwell",
                ISBN = "9780451524935",
                Genre = "Dystopian",
                Price = 9.99m, // Add Price
                Stock = 10, // Use Stock instead of TotalCopies and AvailableCopies
                CreatedAt = DateTime.Now,
                UpdatedAt = DateTime.Now
            });
            Books.Add(new Book
            {
                BookId = 3,
                Title = "To Kill a Mockingbird",
                Author = "Harper Lee",
                ISBN = "9780061120084",
                Genre = "Fiction",
                Price = 11.99m, // Add Price
                Stock = 18, // Use Stock instead of TotalCopies and AvailableCopies
                CreatedAt = DateTime.Now,
                UpdatedAt = DateTime.Now
            });
            Books.Add(new Book
            {
                BookId = 4,
                Title = "The Catcher in the Rye",
                Author = "J.D. Salinger",
                ISBN = "9780316769488",
                Genre = "Fiction",
                Price = 8.99m, // Add Price
                Stock = 6, // Use Stock instead of TotalCopies and AvailableCopies
                CreatedAt = DateTime.Now,
                UpdatedAt = DateTime.Now
            });
            Books.Add(new Book
            {
                BookId = 5,
                Title = "Pride and Prejudice",
                Author = "Jane Austen",
                ISBN = "9780141439518",
                Genre = "Romance",
                Price = 10.99m, // Add Price
                Stock = 12, // Use Stock instead of TotalCopies and AvailableCopies
                CreatedAt = DateTime.Now,
                UpdatedAt = DateTime.Now
            });
            Purchases.Add(new Purchase { PurchaseId = 1, BookId = 1, CustomerId = 2, PurchaseDate = DateTime.Now.AddDays(-5) });
            Purchases.Add(new Purchase { PurchaseId = 2, BookId = 3, CustomerId = 3, PurchaseDate = DateTime.Now.AddDays(-10) });
            Purchases.Add(new Purchase { PurchaseId = 3, BookId = 2, CustomerId = 4, PurchaseDate = DateTime.Now.AddDays(-3) });
            Purchases.Add(new Purchase { PurchaseId = 4, BookId = 4, CustomerId = 5, PurchaseDate = DateTime.Now.AddDays(-7) });
            // Seed Book Circulation Reports
            BookCirculationReports.Add(new BookCirculationReport { BookId = 1, Title = "The Great Gatsby", Author = "F. Scott Fitzgerald", TotalPurchases = 5 });
            BookCirculationReports.Add(new BookCirculationReport { BookId = 2, Title = "1984", Author = "George Orwell", TotalPurchases = 10 });
            BookCirculationReports.Add(new BookCirculationReport { BookId = 3, Title = "To Kill a Mockingbird", Author = "Harper Lee", TotalPurchases = 8 });

            // Seed Overdue Reports
            OverdueReports.Add(new OverdueReport { PuchaseId = 2, BookTitle = "To Kill a Mockingbird", CustomerName = "Mike Jones", PriceAmount = 1.50m });

            // Seed Patron Activity Reports
            // Add customer activity reports
            CustomerActivityReports.Add(new CustomerActivityReport { CustomerName = "Jane Smith", TotalPurchases = 12, OverduePurchases = 1 });
            CustomerActivityReports.Add(new CustomerActivityReport { CustomerName = "Mike Jones", TotalPurchases = 10, OverduePurchases = 2 });
        }
    }

}
