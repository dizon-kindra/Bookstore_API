﻿using BookStore.Data;
using BookStore.Model.DTO;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.ComponentModel.DataAnnotations;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using BookStore.Model;




[ApiController]
[Route("api/[controller]")]
public class CustomerController : ControllerBase
{
    private readonly IConfiguration _configuration;
    private const string Salt = ")GN#447#^nryrETNwrbR%#&NBRE%#%BBDT#%"; // Define the salt here

    public CustomerController(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    [HttpPost("Login")]
    public ActionResult Login([FromBody] Logindto loginDto)
    {
        // Hash the incoming password with the salt
        string hashedPassword = HashPassword(loginDto.Password);

        // Check if the hashed password matches a customer in the list
        var customer = MemoryStorage.Customers.FirstOrDefault(c => c.Username == loginDto.Username && c.Password == hashedPassword);
        if (customer == null)
        {
            return Unauthorized("Invalid login credentials.");
        }

        var token = GenerateJwtToken(customer, loginDto.Platform);
        return Ok(new { Token = token, Message = "Login successful." });
    }

    [HttpPost("Logout")]
    public ActionResult Logout()
    {
        // Note: Logout is typically handled client-side by removing the JWT token.
        return Ok("Logout successful.");
    }

    [HttpPost("Register")]
    public ActionResult Register([FromBody] Customer newCustomer)
    {
        var existingCustomer = MemoryStorage.Customers.FirstOrDefault(c => c.Email == newCustomer.Email);
        if (existingCustomer != null)
        {
            return BadRequest("Email is already registered. Please choose a different one.");
        }

        // Hash the password before storing it
        newCustomer.Password = HashPassword(newCustomer.Password);

        newCustomer.CustomerId = MemoryStorage.Customers.Count + 1;
        MemoryStorage.Customers.Add(newCustomer);
        return Ok("Registered successfully.");
    }

    [HttpPut("UpdateProfile/{id}")]
    public ActionResult UpdateProfile(int id, [FromBody] Customer updatedCustomer)
    {
        var customer = MemoryStorage.Customers.FirstOrDefault(c => c.CustomerId == id);
        if (customer == null) return NotFound("Customer not found.");

        customer.Email = updatedCustomer.Email;

        // Update and hash the password if provided
        if (!string.IsNullOrEmpty(updatedCustomer.Password))
        {
            customer.Password = HashPassword(updatedCustomer.Password);
        }

        return Ok("Profile updated successfully.");
    }

    [HttpGet("GetAllCustomers")]
    public ActionResult<IEnumerable<Customer>> GetAllCustomers()
    {
        var customers = MemoryStorage.Customers;
        if (customers == null || customers.Count == 0)
        {
            return NotFound("No customers found.");
        }

        return Ok(customers);
    }

    [HttpGet("GetCustomer/{id}")]
    public ActionResult<Customer> GetCustomer(int id)
    {
        var customer = MemoryStorage.Customers.FirstOrDefault(c => c.CustomerId == id);
        if (customer == null)
        {
            return NotFound("Customer not found.");
        }

        return Ok(customer);
    }

    private string GenerateJwtToken(Customer customer, string platform)
    {
        var claims = new[] {
            new Claim(JwtRegisteredClaimNames.Sub, customer.Email),
            new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
            new Claim("CustomerId", customer.CustomerId.ToString()),
            new Claim("Platform", platform)
        };

        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["JwSettings:Key"]));
        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

        var token = new JwtSecurityToken(
            _configuration["JwSettings:Issuer"],
            _configuration["JwSettings:Audience"],
            claims,
            expires: DateTime.Now.AddMinutes(30),
            signingCredentials: creds);

        return new JwtSecurityTokenHandler().WriteToken(token);
    }

    private string HashPassword(string password)
    {
        using (var md5 = MD5.Create())
        {
            var saltedPassword = Salt + password;
            var hashBytes = md5.ComputeHash(Encoding.UTF8.GetBytes(saltedPassword));
            return BitConverter.ToString(hashBytes).Replace("-", "").ToLower();
        }
    }
}



