﻿using BookStore.Data;
using BookStore.Model;
using BookStore.Model.DTO;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using BookStore.Data;
using BookStore.Model.DTO;
using BookStore.Model;

namespace BookStore.Controllers
{

    [ApiController]
    [Route("api/[controller]")]
    public class AdminController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private const string Salt = ")GN#447#^nryrETNwrbR%#&NBRE%#%BBDT#%"; // Define the salt here

        public AdminController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpPost("Login")]
        public ActionResult Login([FromBody] Logindto loginDto)
        {
            // Hash the incoming password with the salt
            string hashedPassword = HashPassword(loginDto.Password);

            // Check if the hashed password matches an admin in the list
            var admin = MemoryStorage.Admins.FirstOrDefault(a => a.Username == loginDto.Username && a.Password == hashedPassword);
            if (admin == null)
            {
                return Unauthorized("Invalid login credentials.");
            }

            var token = GenerateJwtToken(admin, loginDto.Platform);
            return Ok(new { Token = token, Message = "Login successful." });
        }

        [HttpPost("Logout")]
        public ActionResult Logout()
        {
            // Note: Logout is typically handled client-side by removing the JWT token.
            return Ok("Logout successful.");
        }

        [HttpPost("Register")]
        public ActionResult Register([FromBody] Admin newAdmin)
        {
            var existingAdmin = MemoryStorage.Admins.FirstOrDefault(a => a.Email == newAdmin.Email);
            if (existingAdmin != null)
            {
                return BadRequest("Email is already registered. Please choose a different one.");
            }

            // Hash the password before storing it
            newAdmin.Password = HashPassword(newAdmin.Password);

            newAdmin.AdminId = MemoryStorage.Admins.Count + 1;
            MemoryStorage.Admins.Add(newAdmin);
            return Ok("Registered successfully.");
        }

        [HttpPut("UpdateProfile/{id}")]
        public ActionResult UpdateProfile(int id, [FromBody] Admin updatedAdmin)
        {
            var admin = MemoryStorage.Admins.FirstOrDefault(a => a.AdminId == id);
            if (admin == null) return NotFound("Admin not found.");

            admin.Email = updatedAdmin.Email;

            // Update and hash the password if provided
            if (!string.IsNullOrEmpty(updatedAdmin.Password))
            {
                admin.Password = HashPassword(updatedAdmin.Password);
            }

            return Ok("Profile updated successfully.");
        }

        [HttpGet("GetAllAdmins")]
        public ActionResult<IEnumerable<Admin>> GetAllAdmins()
        {
            var admins = MemoryStorage.Admins;
            if (admins == null || admins.Count == 0)
            {
                return NotFound("No admins found.");
            }

            return Ok(admins);
        }

        [HttpGet("GetAdmin/{id}")]
        public ActionResult<Admin> GetAdmin(int id)
        {
            var admin = MemoryStorage.Admins.FirstOrDefault(a => a.AdminId == id);
            if (admin == null)
            {
                return NotFound("Admin not found.");
            }

            return Ok(admin);
        }

        private string GenerateJwtToken(Admin admin, string platform)
        {
            var claims = new[] {
            new Claim(JwtRegisteredClaimNames.Sub, admin.Email),
            new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
            new Claim("AdminId", admin.AdminId.ToString()),
            new Claim("Platform", platform)
        };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["JwSettings:Key"]));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                _configuration["JwSettings:Issuer"],
                _configuration["JwSettings:Audience"],
                claims,
                expires: DateTime.Now.AddMinutes(30),
                signingCredentials: creds);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        private string HashPassword(string password)
        {
            using (var md5 = MD5.Create())
            {
                var saltedPassword = Salt + password;
                var hashBytes = md5.ComputeHash(Encoding.UTF8.GetBytes(saltedPassword));
                return BitConverter.ToString(hashBytes).Replace("-", "").ToLower();
            }
        }
    }

}

